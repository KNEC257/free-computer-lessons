import React from "react";

export default function App() {
  return (
    <main className="min-h-screen bg-gray-100 p-6">
      <section className="text-center mb-10">
        <h1 className="text-4xl font-bold text-blue-800 mb-2">
          Free Computer Lessons for Adults
        </h1>
        <p className="text-gray-700 text-lg">
          Empowering adults with essential computer skills – Join our free classes today!
        </p>
      </section>

      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="bg-white p-5 rounded shadow">
          <h2 className="text-2xl font-semibold mb-2">Basic Computer Skills</h2>
          <p className="text-gray-700">Learn how to use a mouse, keyboard, and basic programs.</p>
        </div>

        <div className="bg-white p-5 rounded shadow">
          <h2 className="text-2xl font-semibold mb-2">Internet & Email</h2>
          <p className="text-gray-700">Get familiar with browsing, searching, and email safety.</p>
        </div>

        <div className="bg-white p-5 rounded shadow">
          <h2 className="text-2xl font-semibold mb-2">Microsoft Office</h2>
          <p className="text-gray-700">Intro to Word, Excel, and PowerPoint for everyday use.</p>
        </div>
      </section>

      <section className="mt-12 bg-white p-6 rounded shadow max-w-3xl mx-auto">
        <h2 className="text-3xl font-bold text-center text-blue-700 mb-4">Register for a Free Class</h2>
        <form className="space-y-4">
          <input className="w-full p-2 border border-gray-300 rounded" placeholder="Full Name" />
          <input className="w-full p-2 border border-gray-300 rounded" type="email" placeholder="Email Address" />
          <textarea className="w-full p-2 border border-gray-300 rounded" placeholder="What do you hope to learn?" />
          <button className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700">Submit Registration</button>
        </form>
      </section>
    </main>
  );
}
